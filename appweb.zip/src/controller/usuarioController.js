const Usuario = require('../model/usuario');

function cadastrarUsuario(req, res) {
    const usuario = {
        email: req.body.email,
        senha: req.body.senha,
        nome: req.body.nome,
        data_nascimento: req.body.data_nascimento
    };

    Usuario.create(usuario)
        .then(() => {
            const sucesso = true;
            res.render('index.html', { sucesso });
        })
        .catch((err) => {
            console.error('Error creating user:', err);
            const erro = true;
            res.render('index.html', { erro });
        });
}

function listarUsuarios(req, res) {
    Usuario.findAll()
        .then((usuarios) => {
            res.json(usuarios);
        })
        .catch((err) => {
            console.error('Error fetching users:', err);
            res.status(500).json({ error: 'An error occurred while fetching users.' });
        });
}

module.exports = {
    cadastrarUsuario,
    listarUsuarios
};
