const Anotacao = require('../model/anotacao');

function indexView(req, res) {
    res.render('index.html');
}

function homeView(req, res) {
    Anotacao.findAll({
        where: {
            id_usuario: req.session.usuario.id,
            indicador_ativo: 1
        }
    }).then(anotacoes => {
        res.render('home.html', { anotacoes });
    }).catch(error => {
        console.error('Error fetching notes:', error);
        res.render('home.html', { erro_recupera_anotacoes: error.message });
    });
}

function cadastrarAnotacao(req, res) {
    const anotacao = {
        titulo: req.body.titulo,
        id_usuario: req.session.usuario.id,
        subtitulo: req.body.subtitulo,
        texto: req.body.texto,
        indicador_ativo: 1,
        estilo: req.body.estilo
    };

    Anotacao.create(anotacao)
        .then(() => {
            res.redirect('/home');
        })
        .catch(error => {
            console.error('Error creating note:', error);
            res.render('home.html', { erro_cadastrar_anotacao: error.message });
        });
}

module.exports = {
    indexView,
    homeView,
    cadastrarAnotacao
};
