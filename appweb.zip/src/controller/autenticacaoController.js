const Usuario = require('../model/usuario');

async function autenticar(req, res) {
    try {
        const usuario = await Usuario.findOne({
            where: {
                email: req.body.email,
                senha: req.body.senha
            }
        });

        if (usuario) {
            req.session.autorizado = true;
            req.session.usuario = usuario;
            res.redirect('/home');
        } else {
            const erro_autenticacao = true;
            res.render('index.html', { erro_autenticacao });
        }
    } catch (error) {
        console.error('Error during authentication:', error);
        res.render('index.html', { erro_autenticacao: error.message });
    }
}

function verificarAutenticacao(req, res, next) {
    if (req.session.autorizado) {
        console.log("Usuário autorizado");
        next();
    } else {
        console.log("Usuário NÃO autorizado");
        res.redirect('/');
    }
}

function sair(req, res) {
    req.session.destroy(err => {
        if (err) {
            console.error('Error during session destruction:', err);
            return res.redirect('/home');
        }
        res.redirect('/');
    });
}

module.exports = {
    autenticar,
    verificarAutenticacao,
    sair
};
